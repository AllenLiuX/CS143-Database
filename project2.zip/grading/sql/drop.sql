DROP TABLE Movie;
DROP TABLE Actor;
DROP TABLE Director;
DROP TABLE MovieGenre;
DROP TABLE MovieDirector;
DROP TABLE MovieActor;
DROP TABLE Review;