// dummy code for the converter in JavaScript

console.log("Hello, I am the JSON-to-Relation converter!");