<?php 
/* dummy code for the converter in PHP */

echo "Hello, I am the JSON-to-Relation converter!\n";
?>