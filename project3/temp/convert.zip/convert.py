# dummy code for the converter in Python

print("Hello, I am the JSON-to-Relation converter!")